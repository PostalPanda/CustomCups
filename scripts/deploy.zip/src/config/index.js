// Application Main Config
module.exports = {
  site: {
    // Site configurations on server startup
    enableMaintenanceOnStart: false,
    manualWithdrawsEnabled: true,
    enableLoginOnStart: true,
    // Site endpoints
    backend: {
      productionUrl: "https://api.degencups.io",
      developmentUrl: "http://localhost:5000",
    },

    frontend: {
      productionUrl: "https://degencups.io",
      developmentUrl: "http://localhost:3000",
    },

    adminFrontend: {
      productionUrl: "https://admin.degencups.io",
      developmentUrl: "",
    },
  },

  database: {
    developmentMongoURI: process.env.MONGODB_URL,
    productionMongoURI: process.env.MONGODB_URL, // MongoURI to use in production
  },

  // Each specific game configuration
  games: {
    exampleGame: {
      minBetAmount: 1, // Min bet amount (in coins)
      maxBetAmount: 100000, // Max bet amount (in coins)
      feePercentage: 0.1, // House fee percentage
    },
    race: {
      prizeDistribution: [40, 20, 14.5, 7, 5.5, 4.5, 3.5, 2.5, 1.5, 1], // How is the prize distributed (place = index + 1)
    },
    vip: {
      levels: [
        {
          name: "0",
          wagerNeeded: 0,
          rakebackPercentage: 0,
        },
        {
          name: "1",
          wagerNeeded: 3,
          rakebackPercentage: 0,
        },
        {
          name: "2",
          wagerNeeded: 5,
          rakebackPercentage: 0,
        },
        {
          name: "3",
          wagerNeeded: 10,
          rakebackPercentage: 0,
        },
        {
          name: "4",
          wagerNeeded: 15,
          rakebackPercentage: 0,
        },
        {
          name: "5",
          wagerNeeded: 20,
          rakebackPercentage: 0,
        },
        {
          name: "6",
          wagerNeeded: 30,
          rakebackPercentage: 0,
        },
        {
          name: "7",
          wagerNeeded: 45,
          rakebackPercentage: 0,
        },
        {
          name: "8",
          wagerNeeded: 50,
          rakebackPercentage: 0,
        },
        {
          name: "9",
          wagerNeeded: 70,
          rakebackPercentage: 0,
        },
        {
          name: "10",
          wagerNeeded: 100,
          rakebackPercentage: 0,
        },
        {
          name: "11",
          wagerNeeded: 120,
          rakebackPercentage: 0,
        },
        {
          name: "12",
          wagerNeeded: 150,
          rakebackPercentage: 0,
        },
        {
          name: "13",
          wagerNeeded: 170,
          rakebackPercentage: 0,
        },
        {
          name: "14",
          wagerNeeded: 195,
          rakebackPercentage: 0,
        },
        {
          name: "15",
          wagerNeeded: 200,
          rakebackPercentage: 1,
        },
        {
          name: "16",
          wagerNeeded: 220,
          rakebackPercentage: 1,
        },
        {
          name: "17",
          wagerNeeded: 240,
          rakebackPercentage: 1,
        },
        {
          name: "18",
          wagerNeeded: 260,
          rakebackPercentage: 1,
        },
        {
          name: "19",
          wagerNeeded: 280,
          rakebackPercentage: 1,
        },
        {
          name: "20",
          wagerNeeded: 300,
          rakebackPercentage: 1,
        },
        {
          name: "21",
          wagerNeeded: 320,
          rakebackPercentage: 1,
        },
        {
          name: "22",
          wagerNeeded: 350,
          rakebackPercentage: 1,
        },
        {
          name: "23",
          wagerNeeded: 370,
          rakebackPercentage: 1,
        },
        {
          name: "24",
          wagerNeeded: 400,
          rakebackPercentage: 1,
        },
        {
          name: "25",
          wagerNeeded: 500,
          rakebackPercentage: 2,
        },
        {
          name: "26",
          wagerNeeded: 550,
          rakebackPercentage: 2,
        },
        {
          name: "27",
          wagerNeeded: 570,
          rakebackPercentage: 2,
        },
        {
          name: "28",
          wagerNeeded: 590,
          rakebackPercentage: 2,
        },
        {
          name: "29",
          wagerNeeded: 650,
          rakebackPercentage: 2,
        },
        {
          name: "30",
          wagerNeeded: 690,
          rakebackPercentage: 2,
        },
        {
          name: "31",
          wagerNeeded: 700,
          rakebackPercentage: 2,
        },
        {
          name: "32",
          wagerNeeded: 730,
          rakebackPercentage: 2,
        },
        {
          name: "33",
          wagerNeeded: 750,
          rakebackPercentage: 2,
        },
        {
          name: "34",
          wagerNeeded: 790,
          rakebackPercentage: 2,
        },
        {
          name: "35",
          wagerNeeded: 820,
          rakebackPercentage: 2,
        },
        {
          name: "36",
          wagerNeeded: 850,
          rakebackPercentage: 2,
        },
        {
          name: "37",
          wagerNeeded: 890,
          rakebackPercentage: 2,
        },
        {
          name: "38",
          wagerNeeded: 910,
          rakebackPercentage: 2,
        },
        {
          name: "39",
          wagerNeeded: 930,
          rakebackPercentage: 2,
        },
        {
          name: "40",
          wagerNeeded: 950,
          rakebackPercentage: 3,
        },
        {
          name: "41",
          wagerNeeded: 970,
          rakebackPercentage: 3,
        },
        {
          name: "42",
          wagerNeeded: 990,
          rakebackPercentage: 3,
        },
        {
          name: "43",
          wagerNeeded: 1050,
          rakebackPercentage: 3,
        },
        {
          name: "44",
          wagerNeeded: 1100,
          rakebackPercentage: 3,
        },
        {
          name: "45",
          wagerNeeded: 1130,
          rakebackPercentage: 3,
        },
        {
          name: "46",
          wagerNeeded: 1150,
          rakebackPercentage: 3,
        },
        {
          name: "47",
          wagerNeeded: 1170,
          rakebackPercentage: 3,
        },
        {
          name: "48",
          wagerNeeded: 1200,
          rakebackPercentage: 3,
        },
        {
          name: "49",
          wagerNeeded: 1230,
          rakebackPercentage: 3,
        },
        {
          name: "50",
          wagerNeeded: 1250,
          rakebackPercentage: 4,
        },
        {
          name: "51",
          wagerNeeded: 1300,
          rakebackPercentage: 4,
        },
        {
          name: "52",
          wagerNeeded: 1360,
          rakebackPercentage: 4,
        },
        {
          name: "53",
          wagerNeeded: 1400,
          rakebackPercentage: 4,
        },
        {
          name: "54",
          wagerNeeded: 1500,
          rakebackPercentage: 4,
        },
        {
          name: "55",
          wagerNeeded: 1600,
          rakebackPercentage: 4,
        },
        {
          name: "56",
          wagerNeeded: 1700,
          rakebackPercentage: 4,
        },
        {
          name: "57",
          wagerNeeded: 1800,
          rakebackPercentage: 4,
        },
        {
          name: "58",
          wagerNeeded: 1900,
          rakebackPercentage: 4,
        },
        {
          name: "59",
          wagerNeeded: 2000,
          rakebackPercentage: 4,
        },
        {
          name: "60",
          wagerNeeded: 2100,
          rakebackPercentage: 5,
        },
        {
          name: "61",
          wagerNeeded: 2300,
          rakebackPercentage: 5,
        },
        {
          name: "62",
          wagerNeeded: 2400,
          rakebackPercentage: 5,
        },
        {
          name: "63",
          wagerNeeded: 2600,
          rakebackPercentage: 5,
        },
        {
          name: "64",
          wagerNeeded: 2900,
          rakebackPercentage: 5,
        },
        {
          name: "65",
          wagerNeeded: 3300,
          rakebackPercentage: 5,
        },
        {
          name: "66",
          wagerNeeded: 3600,
          rakebackPercentage: 5,
        },
        {
          name: "67",
          wagerNeeded: 4000,
          rakebackPercentage: 5,
        },
        {
          name: "68",
          wagerNeeded: 4250,
          rakebackPercentage: 5,
        },
        {
          name: "69",
          wagerNeeded: 4500,
          rakebackPercentage: 5,
        },
        {
          name: "70",
          wagerNeeded: 5000,
          rakebackPercentage: 6,
        },
        {
          name: "71",
          wagerNeeded: 5500,
          rakebackPercentage: 6,
        },
        {
          name: "72",
          wagerNeeded: 6000,
          rakebackPercentage: 6,
        },
        {
          name: "73",
          wagerNeeded: 6500,
          rakebackPercentage: 6,
        },
        {
          name: "74",
          wagerNeeded: 6800,
          rakebackPercentage: 6,
        },
        {
          name: "75",
          wagerNeeded: 7000,
          rakebackPercentage: 6,
        },
        {
          name: "76",
          wagerNeeded: 7500,
          rakebackPercentage: 6,
        },
        {
          name: "77",
          wagerNeeded: 7800,
          rakebackPercentage: 6,
        },
        {
          name: "78",
          wagerNeeded: 8000,
          rakebackPercentage: 6,
        },
        {
          name: "79",
          wagerNeeded: 8500,
          rakebackPercentage: 6,
        },
        {
          name: "80",
          wagerNeeded: 9000,
          rakebackPercentage: 7,
        },
        {
          name: "81",
          wagerNeeded: 10000,
          rakebackPercentage: 7,
        },
        {
          name: "82",
          wagerNeeded: 11000,
          rakebackPercentage: 7,
        },
        {
          name: "83",
          wagerNeeded: 12000,
          rakebackPercentage: 7,
        },
        {
          name: "84",
          wagerNeeded: 13000,
          rakebackPercentage: 7,
        },
        {
          name: "85",
          wagerNeeded: 14000,
          rakebackPercentage: 7,
        },
        {
          name: "86",
          wagerNeeded: 15000,
          rakebackPercentage: 7,
        },
        {
          name: "87",
          wagerNeeded: 16000,
          rakebackPercentage: 7,
        },
        {
          name: "88",
          wagerNeeded: 17000,
          rakebackPercentage: 7,
        },
        {
          name: "89",
          wagerNeeded: 18500,
          rakebackPercentage: 7,
        },
        {
          name: "90",
          wagerNeeded: 20000,
          rakebackPercentage: 8,
        },
        {
          name: "91",
          wagerNeeded: 22000,
          rakebackPercentage: 8,
        },
        {
          name: "92",
          wagerNeeded: 24000,
          rakebackPercentage: 8,
        },
        {
          name: "93",
          wagerNeeded: 26000,
          rakebackPercentage: 8,
        },
        {
          name: "94",
          wagerNeeded: 28000,
          rakebackPercentage: 9,
        },
        {
          name: "95",
          wagerNeeded: 30000,
          rakebackPercentage: 9,
        },
        {
          name: "96",
          wagerNeeded: 35000,
          rakebackPercentage: 9,
        },
        {
          name: "97",
          wagerNeeded: 40000,
          rakebackPercentage: 9,
        },
        {
          name: "98",
          wagerNeeded: 45000,
          rakebackPercentage: 9,
        },
        {
          name: "99",
          wagerNeeded: 48500,
          rakebackPercentage: 9,
        },
        {
          name: "100",
          wagerNeeded: 50000,
          rakebackPercentage: 10,
        },
      ],
    },
    affiliates: {
      earningPercentage: 10, // How many percentage of house edge the affiliator will get
    },
    cups: {
      minBetAmount: 0.1, // Min bet amount (in coins)
      maxBetAmount: 100000, // Max bet amount (in coins)
      feePercentage: 0.05, // House fee percentage
    },
    king: {
      minBetAmount: 0.1, // Min bet amount (in coins)
      maxBetAmount: 100000, // Max bet amount (in coins)
      feePercentage: 0.05, // House fee percentage
      autoChooseTimeout: 30000, // Auto-choser timeout in ms
    },
    shuffle: {
      minBetAmount: 0.1, // Min bet amount (in coins)
      maxBetAmount: 100000, // Max bet amount (in coins)
      feePercentage: 0.05, // House fee percentage
      waitingTime: 19000,
    },
    roulette: {
      minBetAmount: 0.1, // Min bet amount (in coins)
      maxBetAmount: 100, // Max bet amount (in coins)
      feePercentage: 0.03, // House fee percentage
      waitingTime: 15000, // Roulette waiting time in ms
    },
    crash: {
      minBetAmount: 0.01, // Min bet amount (in coins)
      maxBetAmount: 150, // Max bet amount (in coins)
      maxProfit: 150, // Max profit on crash, forces auto cashout
      houseEdge: 0.07, // House edge percentage
    },
  },
  blochain: {
    // EOS Blockchain provider API root url
    // without following slashes
    httpProviderApi: "http://eos.greymass.com",
  },
  authentication: {
    jwtSecret: "vf4Boy2WT1bVgphxFqjEY2GjciChkXvf4Boy2WT1hkXv2", // Secret used to sign JWT's. KEEP THIS AS A SECRET 45, dont change this
    jwtExpirationTime: 360000, // JWT-token expiration time (in seconds)
    twilio: {
      accountSid: "ACaa235e5c0bee54ca5ee82ad619b3738c", //leave as it is, phone verification is deactivated
      authToken: "4218e42c3699eae27dd9fb2c0c0bb4b0", //leave as it is, phone verification is deactivated
      verifyServiceSid: "VAc727377e64f0c1b9174d1177c3743e74", //leave as it is, phone verification is deactivated
    },

    // coinbase: {
    //   apiKey: "JeiNJSojGaOalToa",
    //   apiSecret: "V9sfvq8SemWNzKj16vR2qWKrpF0ImF04",
    //   wallets: {
    //     btc: "a98d0b51-ef8c-5338-9463-6e2608ce1676",
    //     eth: "ed37bb67-19a1-508e-ab8e-47876b6ae926",
    //     ltc: "fe557446-d6e0-5bc4-951a-b28c7963ceeb",
    //   },
    // },
    reCaptcha: {
      secretKey: "6LdnqbIhAAAAAAtrekpn-T_30gib2F4D66f-DSqz", //if domain is cryptosplash.live leave as it is
    },
    googleOauth: {
      clientId:
        "897511429668-a8l6ogn4kk521i85st3vp31p6kp6i9vr.apps.googleusercontent.com", //if domain is cryptosplash.live leave as it is
      clientSecret: "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", //if domain is cryptosplash.live leave as it is
    },
    steam: {
      apiKey: "009DF79137DB9FCDFA7D91EB1FE8F047", // Your Steam API key //if domain is cryptosplash.live leave as it is
    },
  },
};
